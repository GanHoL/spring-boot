package com.wkcto.springboot.service;

/**
 * ClassName:UserService
 * <p>
 * Package:com.wkcto.springboot.service
 * Description:
 *
 * @Date:2018/8/7 9:45
 * @Author:蛙课网
 */
public interface UserService {

    public String sayHi(String name);
}
