package com.wkcto.springboot.commons;

/**
 * ClassName:Constants
 * <p>
 * Package:com.wkcto.springboot.commons
 * Description:
 *
 * @Date:2018/8/11 12:05
 * @Author:蛙课网
 */
public class Constants {

    public static final int PAGE_SIZE = 10;

}
